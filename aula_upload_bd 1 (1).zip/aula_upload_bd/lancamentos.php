<?php
include('config/conexao_pdo.php');
$stmt = $pdo->prepare("SELECT l.id, l.`data`, l.lancamento, a.nome FROM lancamento l 
INNER JOIN lancamento_arquivo a ON a.id_lancamento = l.id ");

$stmt->execute();

$lancamentos = $stmt->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload</title>
</head>
<body>
    <h1>Lançamentos</h1>
    <br>
    <p><a href="index.php">Home</a></p>
    <p><a href="cadastrar.php">Cadastrar</a></p>
    <table border=1>
        <tr>
            <th>Id</th>
            <th>Data</th>
            <th>Lançamento</th>
            <th>Arquivo</th>
            <th>Ações</th>
        </tr>
        <?php 
        foreach ($lancamentos as $lancamento) {
            echo "<tr>";
        echo "<td>" . $lancamento['id']."</td>";
            echo "<td>" . $lancamento['data']."</td>";
            echo "<td>" . $lancamento['lancamento']."</td>";
            echo "<td><a href='uploads/". $lancamento['nome']."'>Baixar</a></td>";
            echo "<td><a href='editar.php?id=".$lancamento['id']."'>Editar</a> - <a href='excluir.php?id=".$lancamento['id']."'>Excluir</a> </td>";
            echo "</tr>";
          }
        ?>
    </table>
</body>
</html>