<?php
include('config/conexao_pdo.php');
$stmt = $pdo->prepare("SELECT * FROM produtos p  ");

$stmt->execute();

$produtos = $stmt->fetchAll();


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload</title>
</head>
<body>
    <h1>Produtos</h1>
    <br>
    <p><a href="index.php">Home</a></p>
    <p><a href="cadastrar_produtos.php">Cadastrar</a></p>
    <div>
        <?php 
        foreach ($produtos as $produto) {
          
        echo "<h4>" . $produto['id']." - ". $produto['nome']."</h4>";
        //faz o sql de todas as fotos de um produto
        $stmt2 = $pdo->prepare("SELECT * FROM produtos_fotos f  WHERE id_produto = ".$produto['id']);
            //exetuta a pesquisa
        $stmt2->execute();
        //pega todas as fotos do produto
        $produto_fotos = $stmt2->fetchAll();
        //mostra todas as fotos do produto
        foreach($produto_fotos as $foto){
            echo "<img src='imagens/". $foto['nome']."' width='300' >";
        }
            
            echo "<p><a href='editar.php?id=".$produto['id']."'>Editar</a> - <a href='excluir.php?id=".$produto['id']."'>Excluir</a> </p>";
          
          }
        ?>
    </div>
</body>
</html>