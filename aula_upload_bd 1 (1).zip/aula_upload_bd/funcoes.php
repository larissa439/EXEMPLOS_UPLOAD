<?php
function salva_arquivo($foto,$diretorio,$id_produto,$pdo){
    $nome_foto = uniqid().'_'.(basename($foto['name']));
     
    // Define o caminho completo do arquivo​
    $caminho_arquivo = $diretorio . $nome_foto;

    if(move_uploaded_file($foto['tmp_name'], $caminho_arquivo)){
            
        redimensionamento($foto,$diretorio);

        $sql = "INSERT INTO produtos_fotos(id_produto, nome) VALUES (:id_produto, :nome)";

        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':id_produto', $id_produto);
        $stmt->bindValue(':nome', $nome_foto);
        
        $stmt->execute();
    
        return '';

    } else {

         return 'ERRO';
    }
}


function redimensionamento($foto,$diretorio){
//fazer o redimensionamento da imagem


}

?>