<?php 
include('config/conexao_pdo.php');

if($_POST){
  
    $data = $_POST["data"];
    $lancamento = $_POST['lancamento'];
    $arquivo = $_FILES['arquivo'];

    if(isset($arquivo)) {
        // Define o diretório onde o arquivo será armazenado​
    
        $diretorio = "uploads/";

 
    
        $nome_arquivo2 = uniqid().'_'.(basename($_FILES['arquivo']['name']));
        // Define o caminho completo do arquivo​
    
        $caminho_arquivo2 = $diretorio . $nome_arquivo2;
        if(move_uploaded_file($_FILES['arquivo']['tmp_name'], $caminho_arquivo2)){
            
            $sql = "INSERT INTO lancamento (lancamento, data) VALUES (:lancamento, :data)";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':lancamento', $lancamento);
            $stmt->bindValue(':data', $data);
            
            $stmt->execute();
            $id_lancamento = $pdo->lastInsertId();
            $sql = "INSERT INTO lancamento_arquivo(id_lancamento, nome) VALUES (:id_lancamento, :nome)";

            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id_lancamento', $id_lancamento);
            $stmt->bindValue(':nome', $nome_arquivo2);
            
            $stmt->execute();
        


            echo "Arquivo enviado com sucesso!";
    
        } else {
    
             echo "Ocorreu um erro ao enviar o arquivo.";
        }
    }







   
    echo "<br>Cadastrado com sucesso!";
    echo "<br><a href='index.php'>Lançamentos</a>";
} else {
    echo "ERRO! Informe os dados";
}

?>