<?php 
include('config/conexao_pdo.php');
include('funcoes.php');
        // Define o diretório onde o arquivo será armazenado​
    
        $diretorio = "imagens/";
        //TIPO DE ARQUIVOS VALIDOS
        $mimeTypesValidos = array('image/jpeg', 'image/pjpeg');

if($_POST){
  
    $nome = $_POST["nome"];
    $descricao = $_POST['descricao'];
    $foto1 = $_FILES['foto1'];
    $foto2 = $_FILES['foto2'];
    $foto3 = $_FILES['foto3'];

    if($foto1['name'] != '' ) {

        if (!in_array($foto1['type'],  $mimeTypesValidos)) {
            echo "Erro: Tipo MIME inválido. Envie apenas imagens JPG.";
            exit;
        }
    }
    if($foto2['name'] != '' ) {

        if (!in_array($foto2['type'],  $mimeTypesValidos)) {
            echo "Erro2: Tipo MIME inválido. Envie apenas imagens JPG.";
            exit;
        }
    }
    if($foto3['name'] != '' ) {

        if (!in_array($foto3['type'],  $mimeTypesValidos)) {
            echo "Erro3: Tipo MIME inválido. Envie apenas imagens JPG.";
            exit;
        }
    }
    $sql = "INSERT INTO produtos (nome, descricao) VALUES (:nome, :descricao)";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':nome', $nome);
    $stmt->bindValue(':descricao', $descricao);
    
    $stmt->execute();
    $id_produto = $pdo->lastInsertId();
    if(isset($foto1)){
        $erro = salva_arquivo($foto1,$diretorio,$id_produto,$pdo);
    }

    if(isset($foto2)){
        $erro =salva_arquivo($foto2,$diretorio,$id_produto,$pdo);
    }
    if(isset($foto3)){
        $erro =salva_arquivo($foto3,$diretorio,$id_produto,$pdo);
    }
    
 
    echo "<br>Cadastrado com sucesso!";
    echo "<br><a href='produtos.php'>Produtos</a>";
} else {
    echo "ERRO! Informe os dados";
}

?>