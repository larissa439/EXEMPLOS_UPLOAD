<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload</title>
</head>
<body>
<h1>Cadastro de Lançamento</h1>
    <br>
    <form action="salvar_cadastro.php" method="post" enctype="multipart/form-data">
        <p>Data</p>
        <p><input type="DATE" name="data" id="data" ></p>
        <br>
        <p>Lançamento</p>
        <p><input type="text" name="lancamento" id="lancamento" ></p>
        <br>
        <p>Arquivo</p>
        <p><input type="file" name="arquivo" id="arquivo" ></p>
        <br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>