<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload</title>
</head>
<body>
<h1>Cadastro de Produto</h1>
    <br>
    <form action="salvar_cad_produto.php" method="post" enctype="multipart/form-data">
        <p>Nome</p>
        <p><input type="text" name="nome" id="nome" ></p>
        <br>
        <p>Descrição</p>
        <p><textarea name="descricao" id="descricao"></textarea></p>
        <br>
        <p>Foto1</p>
        <p><input type="file" name="foto1" id="foto1" ></p>
        <br>
        <p>Foto 2</p>
        <p><input type="file" name="foto2" id="foto2" ></p>
        <br>
        <p>Foto 3</p>
        <p><input type="file" name="foto3" id="foto3" ></p>
        <br>
        <input type="submit" value="Salvar">
    </form>
</body>
</html>